﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                peso = Convert.ToDouble(mskbxPeso.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Peso inválido" + ex.Message);
                mskbxPeso.Focus();
            }
            try
            {
                altura = Convert.ToDouble(mskbxAltura.Text);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Altura inválida" + ex.Message);
                mskbxAltura.Focus();
            }
            imc = Math.Round(peso / (altura * altura), 1);
            txtImc.Text = imc.ToString("n1");

            if (imc < 18.5)
                MessageBox.Show("Magreza, Obesidade grau 0");
            else if (imc <= 24.9)
                MessageBox.Show("Normal, Obesidade grau 0");
            else if (imc <= 29.9)
                MessageBox.Show("Sobrepeso, Obesidade grau I");
            else if (imc <= 39.9)
                MessageBox.Show("Obesidade, Obesidade grau II");
            else
                MessageBox.Show("Obesidade Grave, Obesidade grau III");

        }
    }
}
