﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATV1
{
    public partial class Form1 : Form
    {
        double Volume, Raio, Altura;

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void lblVolume_Click(object sender, EventArgs e)
        {

        }

        private void lblAltura_Click(object sender, EventArgs e)
        {

        }

        private void txtAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text, out Altura) || (Altura <= 0))
            {
                MessageBox.Show("altura invalida!");
            }
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if (!double.TryParse(txtRaio.Text, out Raio) || (Raio <= 0))
            {
                MessageBox.Show("raio invalido!");
                txtRaio.Focus();
            }
            else
            {

                if (!double.TryParse(txtAltura.Text, out Altura) || (Altura <= 0))
                {
                    MessageBox.Show("altura invalida!");
                    txtAltura.Focus();
                }
                else

                    Volume = Math.PI * Math.Pow(Raio, 2) * Altura;
                txtVolume.Text = Volume.ToString("N2");
            }
        }
        private void txtRaio_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtAltura.Text = "";
            txtRaio.Text = "";
            txtVolume.Text = "";
        }

        private void txtAltura_TextChanged(object sender, EventArgs e)
        {

        }

      

        private void txtRaio_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtRaio.Text, out Raio)||(Raio<=0))
            {
                MessageBox.Show("raio invalido!");
            }
        }
        
    }
}
