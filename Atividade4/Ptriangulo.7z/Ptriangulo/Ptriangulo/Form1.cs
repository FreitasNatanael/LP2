﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptriangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            double lado1, lado2, lado3;
            if (!Double.TryParse(txtLado1.Text, out lado1) ||
               !Double.TryParse(txtLado2.Text, out lado2) ||
               !Double.TryParse(txtLado3.Text, out lado3)||
               lado1 == 0 ||lado1<0|| string.IsNullOrEmpty(txtLado1.Text) ||
               lado2 == 0 ||lado2<0|| string.IsNullOrEmpty(txtLado2.Text) ||
               lado3 == 0 ||lado3<0|| string.IsNullOrEmpty(txtLado3.Text))




                MessageBox.Show("Insira apenas NUMEROS maiores que 0 nos campos.");//testa se eh numero, se for continua no else

            else
            {
                if (Math.Abs(lado2 - lado3) < lado1 || lado1 < lado2 + lado3 ||
                    Math.Abs(lado1 - lado3) < lado2 || lado2 < lado1 + lado3 ||
                    Math.Abs(lado1 - lado2) < lado3 || lado3 < lado1 + lado2)//caso seja triangulo faz o calculo, caso contrario else

                {
                    if (lado1 == lado2 && lado1 == lado3)
                        MessageBox.Show("Eh um triangulo equilatero");
                    else if (lado1 == lado2 || lado2 == lado3 || lado1 == lado3)
                        MessageBox.Show("Eh um triangulo isosceles");
                    else MessageBox.Show("Eh um triangulo escaleno");

                }
                else MessageBox.Show("Nao eh triangulo");


            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
