﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATV8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for (int i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox("Digite o número", "Entrada de dados");
                if (auxiliar == "")
                    break;

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("numero invalido");
                    i--;
                }
            }

            Array.Reverse(vetor);
            auxiliar = "";
            foreach (int i in vetor)
            {
                auxiliar += i + "\n";
            }
           MessageBox.Show(auxiliar);
        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20,3];
            string auxiliar = "";
            double media = 0;
            string stringona = "";



            for (int i=0; i<20; i++)
            {
                for (int j=0; j<3; j++)
                {
                    auxiliar = Interaction.InputBox("Insira a nota {j+1} do aluno {i+1");
                    if (!double.TryParse(auxiliar, out notas[i,j]) || (notas[i,j] < 0) || (notas[i,j] > 10))
                    {
                        MessageBox.Show("nota invalida");
                        j--;
                        media += notas[i, j];
                    }
                    media = media / 3;
                    stringona += "Aluno" + i+1 + ": Média :+" + media.ToString("N2") + "\n";

                }
            }
            MessageBox.Show(stringona);
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            frmEx4 obj4 = new frmEx4();
            obj4.Show();


        }
    }
}
