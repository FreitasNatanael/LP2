﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PAluno2
{
    public partial class Form1 : Form
    {
        string[,] vetor = new string[2, 3];
        double[,] vetorDouble = new double[2, 3];
        double media = 0;
        double media2 = 0;
        int i = 0, j = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            listBox.Text = "";

            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    vetor[i, j] = Interaction.InputBox(" Aluno " + (i + 1) + " Nota do professor" + (j + 1), "Entrada de dados");

                    if (!double.TryParse(vetor[i, j], out vetorDouble[i, j]))
                    {
                        MessageBox.Show("Insira um Numero");
                        j--;
                    }

                    else if (Convert.ToDouble(vetor[i, j]) < 0)
                    {
                        MessageBox.Show("Número inválido, tente novamente");
                        j--;
                    }
                    else
                    {
                        listBox.Items.Add("Aluno " + (i + 1) + " Nota do professor " + (j + 1) + " :" + vetor[i, j]);
                    }
} 
                media = ((vetorDouble[0, 0] + vetorDouble[0, 1] + vetorDouble[0, 2] / 3));
                media2 = ((vetorDouble[1, 0] + vetorDouble[1, 1] + vetorDouble[1,2] / 3));


                listBox.Items.Add("Media : " + media );

            }
            listBox.Items.Add("Media : " + media2);
        }
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listBox.Items.Clear();
             
        }
    }
}
