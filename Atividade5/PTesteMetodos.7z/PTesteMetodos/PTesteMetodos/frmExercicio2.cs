﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTesteMetodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btnTestar_Click(object sender, EventArgs e)
        {

        }

        private void frmExercicio2_Load(object sender, EventArgs e)
        {

        }

        private void btnInserirTexto_Click(object sender, EventArgs e)
        {

        }

        private void btnInserirAsteriscos_Click(object sender, EventArgs e)
        {

        }

        private void txtPalavra2_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPalavra1_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblPalavra1_Click(object sender, EventArgs e)
        {

        }
    }
}
